//Define GPIO pin 4 of the ESP32-S3 microcontroller
//Function declarations for the Shear Module and ADC conversion

#ifndef SHEAR_SENSOR_H
#define SHEAR_SENSOR_H

const int shearSensorPin = 4; //gpio pin 4 

//ADC setup
const float referenceADCVoltage = 3.2; // voltage input value; maximum voltage set for the ESP32-S3 ADC input -> pin 4
const int maxADCValue = 4095;   //ADC output value; ESP32-S3 uses 12-bit ADC resolution to read/represent values to the serial monitor

void initializeShearSensor(); //configures the shear sensor pins -> input 
int readShearSensorADC();//reads the analog value from shear sensors
float convertADCToVoltage(int adcValue); //converts the digital ADC number back into a voltage; scaling conversion => (adcValue/maxADCValue)*referenceADCVoltage

#endif
