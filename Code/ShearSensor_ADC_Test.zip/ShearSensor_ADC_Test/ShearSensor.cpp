//ADC sensor readings

#include<Arduino.h>
#include "ShearSensor.h"

void initializeShearSensor()
{
  pinMode(shearSensorPin, INPUT);
}

//Read raw ADC values
int readShearSensorADC()
{
  return analogRead(shearSensorPin); //gets ADC value from shear sensor connected to GPIO pin 4
}

//Convert ADC value to voltage value
float convertADCToVoltage(int adcValue)
{
  return (adcValue * referenceADCVoltage) / maxADCValue;
}