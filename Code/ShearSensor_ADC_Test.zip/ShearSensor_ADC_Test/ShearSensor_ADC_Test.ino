//Shear sensor testing for function generator + Serial Plotter validation
//ADC shear testing 
/*ESP32-S2 configured to read an analog input from the shear sensor channel on GPIO pin 4. A function generator (Testing method) is used in place of the sensor to apply a known
100Hz test signal within the safe ADC input range. The microcontroller sampled the analog input using analogRead() and transmitted the digital values through serial communication
to the Serial Plotter. This is to demonstrate that the microcontroller ESP32-S3 could succesfully aquire and display the shear sensor input waveform without requiring an 
oscilloscope.
*/
//Goal: Microcontroller can read the shear sensor input on pin 4, can convert that analog input into digital readings, the readings can be shown in the Serial Plotter/Monitor
//Testing : Function generator -> ESP32-S3 GPIO pin 4/ADC input -> Code -> Serial plotter

/*Hardware settings:
-Maximum voltage peak = 3.2V 
-Frequency = 100Hz
-Signal - sine wave
-Amplitude = 1.5V
-Offset = 1.5V
*/
/****************************************************************************************************************************************************************************/

#include "ShearSensor.h"

void setup() // put your setup code here, to run once:
{
  Serial.begin(115200);
  delay(1000);

  initializeShearSensor();
}

void loop() 
{
  // put your main code here, to run repeatedly:
  int adcValue = readShearSensorADC();
  float voltage = convertADCToVoltage(adcValue);  //scaled voltage value of ADC value

  //Serial Plotter output
  Serial.print("Shear_ADC:"); 
  Serial.print(adcValue); //prints ADC value
  Serial.print(","); 

  Serial.print("Voltage:"); 
  Serial.println(voltage, 3); //prints voltage value with 3 decimal places

  //Serial Monitor Output ; Real time readings 
  Serial.print("ADC Value: ");
  Serial.print(adcValue);
  Serial.print(" | voltage: ");
  Serial.println(voltage, 3); //3 decimal places

  delay(5); //sampling speed 

}
