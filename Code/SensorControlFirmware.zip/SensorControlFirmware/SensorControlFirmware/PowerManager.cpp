/*Implemented to handle through battery voltage reads, digital charging inputs, and software controlled states architectured as a state machine. */

#include "PowerManager.h"

//Defined Pins
static const int batteryPin = 34; //Battery analog input pin
static const int usbChargePin = 27; //USB-C charge detection digital input pin  

//Defined variables for Module
static int batteryAnalogData = 0; //raw analog readings from the batteryPin
static bool isCharging = false; //charging status, assuming not charging unitil inputs reads occur. 
static SystemOperationMode currentMode = OFF; //stores the current operating mode -> currentMode

//Initialize Power Manager Hardware for power related settings
void initializeBatteryPower()//prepares module for use
{
  //setting the charging pin 
  pinMode(usbChargePin, INPUT); //sets the charging pin -> input
  currentMode = IDLE; //sets the starting mode
}

//Reads battery level
void readBatteryLevel()
{
  batteryAnalogData = analogRead(batteryPin); //reads analog signal from battery -> batteryAnalogData
}

//Reads charging status
void readChargingStatus()
{
  //Checks if charging is detected
  isCharging = digitalRead(usbChargePin); //returns true if signal active else false for inactive signal
}

//update system mode 
void updateSystemMode()
{
  if(isCharging)
  {
    currentMode = CHARGING; //sets to charging mode
  }
  else if (batteryAnalogData < 1000) //checks if the battery reading < low battery threshold
  {
    currentMode = LOW_POWER; //sets to lower power if the battery is < low battery threshold
  }
  else
  {
    currentMode = ACTIVE; //normal active operating mode 
  }
}

void printPowerStatus()
{
  Serial.print("Battery ADC value: ");
  Serial.println(batteryAnalogData); 

  Serial.print("Charging status: ");
  Serial.println(isCharging ? "Charging" : "Not Charging");

  Serial.print("Current Mode: ");
  switch (currentMode)
  {
    case OFF: 
      Serial.println("OFF");
      break; 
    case IDLE:
      Serial.println("IDLE");
      break;
    case ACTIVE: 
      Serial.println("ACTIVE");
      break;
    case LOW_POWER:
      Serial.println("LOW_POWER");
      break;
    case CHARGING: 
      Serial.println("CHARGING");
      break;
    case FAULT:
      Serial.println("FAULT");
      break;
    default: 
      Serial.println("UNKNOWN");
      break;
  }
}

//Other usefeul functions for debugging and accessing internal values
int getBatteryLevel()
{
  return  batteryAnalogData;
}

bool getChargingStatus()
{
    return isCharging;

}
SystemOperationMode getCurrentMode()
{
  return currentMode;  
}

