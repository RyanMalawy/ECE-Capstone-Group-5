/*Implementation is to define pressure sensor pins,, sample pressure sensors, map each sensor to the correct regions on the insole 
and store analog readings for the processing modules. */

#include "PressureSensorInterface.h"

//Defined pressure sensor pins
static const int pressurePins[NUM_OF_PRESSURE_SENSORS] = { 17, 18, 19, 20}; //mapping analog input pins for each sensor

//Storage variables for sensor data
static int pressureAnalogData[NUM_OF_PRESSURE_SENSORS] = {0}; //array to store raw analog reading 
static float pressureFiltered[NUM_OF_PRESSURE_SENSORS] = {0.0}; //stores each sensor filtered data

static int sensorCounter; //tracks pressure sensor mapping

void initializePressureSensors()
{
  for(sensorCounter = 0; sensorCounter < NUM_OF_PRESSURE_SENSORS; sensorCounter++)
  {
    //reads voltage from sensors
    pinMode(pressureAnalogData[sensorCounter], INPUT); //sets each sensor pin -> INPUT 
  }

}

void readPressureSensors()
{
  for(sensorCounter = 0; sensorCounter < NUM_PRESSURE_SENSORS; sensorCounter)
  {
    pressureAnalogData[sensorCounter] = analogRead(pressurePins[sensorCounter]); //reads analog voltage from sensor pin
  }
}
//what filter design is designed in the functional architecture?
void filterPressureData()
{
  for(sensorCounter = 0; sensorCounter < NUM_OF_PRESSURE_SENSORS; sensorCounter++)
  {
    //Filtering as a low pass filter using 80% new readings and 20% prev filtered value to reduce unstable/noisy readings
    pressureFiltered[sensorCounter] = (pressurePin[sensorCounter] * 0.8) + (pressureFiltered[sensorCounter] * 0.2);
  }
}

//Functions: Accessing internal data

int getPressureAnalogSignal(int sensorIndex)
{
  return pressureAnalogData[sensorIndex]; //returns raw analog sensor readings at the sensor index
}

float getPressureFiltered(int sensorIndex)
{
  return pressureFiltered[sensorIndex]; // returns filtered pressure data at the sensor index
}





