/*Purpose: This modules reads the analog pressure signals from the insole sensors and stores and sends the raw values for processing.*/

#ifndef PRESSURE_SENSOR_INTERFACE_H
#define PRESSURE_SENSOR_INTERFACE_H

#include <Arduino.h> 

//Number of pressure sensors in the insole
#define NUM_PRESSURE_SENSORS 4 //number of pressure sensors in the insole

//Function Declarations
void initializePressureSensors();//sets the pressure sensor pins
void readPressureSensors(); //read analog sensor data values
void filterPressureData(); //apply filtering to remove noise from the signals
int getPressureAnalogSignal(int sensorCounter); //returns analog readings of a selected pressure sensor
float getPressureFiltered(int sensorCounter); //returns filtered value of a selected pressure sensor

#endif
