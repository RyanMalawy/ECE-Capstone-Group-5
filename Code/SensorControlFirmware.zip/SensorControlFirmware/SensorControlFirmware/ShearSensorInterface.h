/*Purpose: This modules reads the analog shear force sensor signlas and prepares the raw values for processing.*/

#ifndef SHEAR_SENSOR_INTERFACE_H
#define SHEAR_SENSOR_INTERFACE_H
#include <Arduino.h>

#define NUM_SHEAR_SENSORS 4   //number of shear force sensors

//Function Declaration
void initializeShearSensors();  //configures the shear sensor pins -> input 
void readShearSensors();  //reads the analog values from shear sensors
void filterShearData(); ////apply filtering to remove noise from the signals
int getShearAnalogSignal(int sensorIndex);  //returns the analog reading of a selected shear sensor
float getShearFiltered(int sensorIndex); //returns filtered value of a selected shear sensor

#endif