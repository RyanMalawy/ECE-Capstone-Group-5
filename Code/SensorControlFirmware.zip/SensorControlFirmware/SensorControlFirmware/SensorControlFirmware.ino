//microcontroller - ESP32S3
/* For Phase 1, the main firmware directly coordinates each firmware modules as follows: Power and mode manager, shear sensor manager, and pressure sensor manager. 
The firmware follows a execution flow where the system powers on, the microcontroller executes the setup() function to perform the initialization. During this stage, 
serial communication, power and mode manage configured, and all shear and pressure sensors are initialized. 

After initialization the functionality of the system has its own basic task for power manage, pressure and shear sensor interface. Within the loop() function, 
the firmware performs each tasks. First, the PowerManager reads the battery level and charging status and updates the current operating mode accordingly. Next, 
the firmware reads raw data from the pressure and shear sensors and applies filtering to reduce noise and stabalize the sensor signals. Continuation of the project,
these processed sensor values can represent the gait analysis movement detected across the shoe insole. 

The firmware then outputs system status and sensor reading through the serial interface for monitoring which allows the system to continuously monitor sensor data 
and system conditions in real time. */

#include "PowerManager.h"
#include "PressureSensorInterface.h"
#include "ShearSensorInterface.h"

void setup() 
{
  Serial.begin(115200); //communication speed (baud rate) 

//Initialize the hardware 
  initializeBatteryPower(); 
  initializePressureSensors(); 
  initializeShearSensors(); 
}

void loop() 
{        
  //Task : power and mode of operations
  readBatteryLevel(); 
  readChargingStatus();
  updateSystemMode();  

  //Task: Pressure sensor processing
  readPressureSensors(); 
  filterPressureData();
  
  //Task: Shear sensor processing
  readShearSensors();
  filteredShearData();

  printPowerStatus(); 

  //Print pressure sensor data
  for(int i = 0; i < NUM_OF_PRESSURE_SENSORS; i++)
  {
    Serial.print("Pressure Sensor ");
    Serial.print(i);
    Serial.print("Raw Analog data: ");
    Serial.print(getPressureAnalogSignal(i));

    Serial.print(" Filtered: ");
    Serial.println(getPressureFiltered(i));
  }

  //Print shear sensor data
  for(int i = 0; i < NUM_OF_SHEAR_SENSORS; i++)
  {
    Serial.print("Pressure Sensor ");
    Serial.print(i);
    Serial.print("Raw Analog data: ");
    Serial.print(getShearAnalogSignal(i));

    Serial.print(" Filtered analog data: ");
    Serial.println(getShearFiltered(i));
  }

  Serial.println(".................................");

  delay(1000);
}
