/*Purpose: This module monitors power conditions and manages device operating modes. */

#ifndef POWER_MANAGER_H
#define POWER_MANAGER_H
#include <Arduino.h>  //Ardiuno function library

//Declaring power manager system set of operation modes states:
enum SystemOperationMode
{
  OFF, //System powered down
  ACTIVE, //System is actively performing main functions of the system
  IDLE, //Waiting state while the system is powered on
  LOW_POWER, //low battery detection
  CHARGING, //device detects USB-C charging
  FAULT   //error detection in the system
};

//Function Declarations:
void initializeBatteryPower();  //initialize power manager
void readBatteryLevel();  // reads battery level; battery voltage
void readChargingStatus(); // reads charging status, checks if the device is charging
void updateSystemMode();  // updates system mode, decides which state the system is in
void printPowerStatus();  // debugging, prints information to the serial monitor
//other useful functions 
int getBatteryLevel(); //returns the battery reading
bool getChargingStatus(); //indicates charging state: returns true value -> charging, false value -> not charging
SystemOperationMode getCurrentMode(); // returns the current operation mode state of the system

#endif // end of header file