/*Implementation is to define shear sensor pins mappedd to the placement/ regions of the insole, sample shear sensors, organize the readings
by sensor location and store analog shear data.*/

#include "ShearSensorInterface.h"

//Define sensor pins
static const int shearSensorPins[NUM_OF_SHEAR_SENSORS] = {25, 26, 27, 28};

//Storage variables for sensor data
static int shearAnanlogData[NUM_OF_SHEAR_SENSORS] = {0};
static float shearFiltered[NUM_OF_SHEAR_SENSORS] = {0.0};

static int sensorCounter; //tracks shear sensor mapping

//Defined functions

void initializeShearSensors() 
{
  for(sensorCounter = 0; sensorCounter < NUM_OF_SHEAR_SENSORS; sensorCounter++)
  {
      pinMode(shearSensorPins[NUM_OF_SHEAR_SENSORS], INPUT); //sets each shear sensor pin -> INPUT
  }
}

void readShearSensors()
{
  for(sensorCounter = 0; sensorCounter < NUM_OF_SHEAR_SENSORS; sensorCounter++)
  {
    shearAnalogData[sensorCounter] = analogRead(shearSensorPin[sensorCounter]); //reads the analog values from shear sensors -> analog data 
  }
}

//basic filtering - placeholder
void filterShearData() //apply filtering to remove noise from the signals
{
  for(sensorCounter = 0; sensorCounter < NUM_OF_SHEAR_SENSORS; sensorCounter++)
  {
    //to reduce spikes and noise, using 80% new readings and 20% prev filtered value to reduce unstable/noisy readings
    shearFiltered[sensorCounter] = (shearSensorPins[sensorCounter] * 0.8) + (shearFiltered[sensorCounter] * 0.2);
  }
}

int getShearAnalogSignal(int sensorIndex) 
{
  return shearAnalogData[sensorIndex]; //returns the analog reading of a selected shear sensor
}
float getShearFiltered(int sensorIndex) 
{
  return shearFiltered[sensorIndex]; //returns filtered value of a selected shear sensor
}


